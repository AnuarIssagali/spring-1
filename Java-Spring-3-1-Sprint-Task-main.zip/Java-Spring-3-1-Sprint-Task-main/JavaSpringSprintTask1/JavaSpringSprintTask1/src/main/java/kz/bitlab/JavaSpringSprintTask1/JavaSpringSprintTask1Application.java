package kz.bitlab.JavaSpringSprintTask1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSpringSprintTask1Application {

	public static void main(String[] args) {
		SpringApplication.run(JavaSpringSprintTask1Application.class, args);
	}

}
